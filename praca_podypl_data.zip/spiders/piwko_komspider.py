# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 21:51:23 2019

@author: Piotrek
"""

import scrapy
import time
from selenium import webdriver
from piwko_kom.items import PiwkoKomItem
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


def removeAccents(input_text):
    #http://gentle.pl/2017/07/19/usuwanie_polskich_znakow_python.html
    strange='ŮôῡΒძěἊἦëĐᾇόἶἧзвŅῑἼźἓŉἐÿἈΌἢὶЁϋυŕŽŎŃğûλВὦėἜŤŨîᾪĝžἙâᾣÚκὔჯᾏᾢĠфĞὝŲŊŁČῐЙῤŌὭŏყἀхῦЧĎὍОуνἱῺèᾒῘᾘὨШūლἚύсÁóĒἍŷöὄЗὤἥბĔõὅῥŋБщἝξĢюᾫაπჟῸდΓÕűřἅгἰშΨńģὌΥÒᾬÏἴქὀῖὣᾙῶŠὟὁἵÖἕΕῨčᾈķЭτἻůᾕἫжΩᾶŇᾁἣჩαἄἹΖеУŹἃἠᾞåᾄГΠКíōĪὮϊὂᾱიżŦИὙἮὖÛĮἳφᾖἋΎΰῩŚἷРῈĲἁéὃσňİΙῠΚĸὛΪᾝᾯψÄᾭêὠÀღЫĩĈμΆᾌἨÑἑïოĵÃŒŸζჭᾼőΣŻçųøΤΑËņĭῙŘАдὗპŰἤცᾓήἯΐÎეὊὼΘЖᾜὢĚἩħĂыῳὧďТΗἺĬὰὡὬὫÇЩᾧñῢĻᾅÆßшδòÂчῌᾃΉᾑΦÍīМƒÜἒĴἿťᾴĶÊΊȘῃΟúχΔὋŴćŔῴῆЦЮΝΛῪŢὯнῬũãáἽĕᾗნᾳἆᾥйᾡὒსᾎĆрĀüСὕÅýფᾺῲšŵкἎἇὑЛვёἂΏθĘэᾋΧĉᾐĤὐὴιăąäὺÈФĺῇἘſგŜæῼῄĊἏØÉПяწДĿᾮἭĜХῂᾦωთĦлðὩზკίᾂᾆἪпἸиᾠώᾀŪāоÙἉἾρаđἌΞļÔβĖÝᾔĨНŀęᾤÓцЕĽŞὈÞუтΈέıàᾍἛśìŶŬȚĳῧῊᾟάεŖᾨᾉςΡმᾊᾸįᾚὥηᾛġÐὓłγľмþᾹἲἔбċῗჰხοἬŗŐἡὲῷῚΫŭᾩὸùᾷĹēრЯĄὉὪῒᾲΜᾰÌœĥტ'
    ascii_replacements='UoyBdeAieDaoiiZVNiIzeneyAOiiEyyrZONgulVoeETUiOgzEaoUkyjAoGFGYUNLCiIrOOoqaKyCDOOUniOeiIIOSulEySAoEAyooZoibEoornBSEkGYOapzOdGOuraGisPngOYOOIikoioIoSYoiOeEYcAkEtIuiIZOaNaicaaIZEUZaiIaaGPKioIOioaizTIYIyUIifiAYyYSiREIaeosnIIyKkYIIOpAOeoAgYiCmAAINeiojAOYzcAoSZcuoTAEniIRADypUitiiIiIeOoTZIoEIhAYoodTIIIaoOOCSonyKaAsSdoACIaIiFIiMfUeJItaKEISiOuxDOWcRoiTYNLYTONRuaaIeinaaoIoysACRAuSyAypAoswKAayLvEaOtEEAXciHyiiaaayEFliEsgSaOiCAOEPYtDKOIGKiootHLdOzkiaaIPIIooaUaOUAIrAdAKlObEYiINleoOTEKSOTuTEeiaAEsiYUTiyIIaeROAsRmAAiIoiIgDylglMtAieBcihkoIrOieoIYuOouaKerYAOOiaMaIoht'
    translator=str.maketrans(strange,ascii_replacements)
    return input_text.translate(translator)

class PiwkoKomSpider(scrapy.Spider):
    name = 'piwko_komspider'
    start_urls = ['https://ocen-piwo.pl/weihenstephaner-hefe-weissbier-s1-n418']
    #['https://ocen-piwo.pl/eb-premium-nowe-2015-s1-n3199']
    #['https://ocen-piwo.pl/emu-bitter-s1-n3510'] 
    #['https://ocen-piwo.pl/the-garden-brewery-india-pale-ale-s1-n10404']
    #['https://ocen-piwo.pl/fourpure-spice-route-s1-n10703']
    #['https://ocen-piwo.pl/three-happy-brewers-belgian-enkel-s1-n11295']  
    #['https://ocen-piwo.pl/anarchia-anarchy-pale-ale-s1-n11305']
    #['https://ocen-piwo.pl/minister-ein-minister-s1-n11744']
    #['https://ocen-piwo.pl/stu-mostow-salamander-gose-nectatin-and-passionfruit-s1-n16234'] 
    # ['https://ocen-piwo.pl/pinta-atak-chmielu-s1-n333'] #
    allowed_domains = ['ocen-piwo.pl']

    def __init__(self):
        self.driver = webdriver.Firefox(executable_path=r'C:\geckodriver.exe')

    def parse(self, response):
        self.driver.get(response.url)
        self.driver.implicitly_wait(5)
        j=4

        osiemn = self.driver.find_element_by_xpath("//input[@value='Przejdź do serwisu']")
        osiemn.click()    

        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//button[@class='align-right secondary popover-button' and @id='onesignal-popover-cancel-button']"))).click()
        time.sleep(5)
        
        while True:
            if "Na razie brak komentarzy" in self.driver.page_source:
                self.driver.find_elements_by_xpath(".//*[@style='text-align:right;width:680px;margin-bottom:10px;']/a")[-1].click()
                time.sleep(5)
                #print('brak') 
            
            try: 
                comments = self.driver.find_elements_by_class_name('comment')
                users = self.driver.find_elements_by_xpath("//*[@class='above400']")
                name = self.driver.find_elements_by_xpath('.//fieldset/legend/a')
                                                           
                u2=[]
                for u in users:
                    if u.text!='':
                        u2.append(u.text)    
    
                for u,c in zip(u2, comments):
                    item = PiwkoKomItem()
                    item['name']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(name[0].text.replace('\n', ' ')) ]),
                    item['user']= removeAccents(u.replace('\n', ' '))
                    item['koment']=''.join([i if ord(i) < 128 else ' ' for i in removeAccents(c.text.replace('\n', ' ')) ])
                    yield item
        
                button = self.driver.find_element_by_xpath("//a[@onclick='zmien_komentarze(" + str(j)+")']")
                button.click()
                j+=4
    
            except:
                #break
                self.driver.find_elements_by_xpath(".//*[@style='text-align:right;width:680px;margin-bottom:10px;']/a")[-1].click()
                time.sleep(5)

        self.driver.close()  


    def scrape(self, response):
        SET_SELECTOR = ".//div[@id='komentarze_lista']/table/tr"
        nm = "//*[@id='a_333']/text()"        

        for kom in response.xpath(SET_SELECTOR):
            item = PiwkoKomItem()
            user ="./td//text()"
            koment = "./td/div/text()"
            smak = './td/div/div/div/text()'
            ocena = './td/div/div/div//b/text()'
            
            #item['url']= response.request.url,
            item['name']= kom.xpath(nm).extract_first(),
            item['user']= kom.xpath(user).extract_first()
            item['koment']=kom.xpath(koment).extract_first(),
            item['smak']=kom.xpath(smak).extract_first(),
            item['ocena']=kom.xpath(ocena).extract_first(),
            yield item
            
        #NEXT_PAGE_SELECTOR = ".//*[@style='text-align:center;width:100%;']/a/@href"    
        #next_page = response.xpath(NEXT_PAGE_SELECTOR)[-1].extract()
        #if next_page:
        #    yield scrapy.Request(
        #            response.urljoin(next_page),
        #            callback=self.parse
        #            )


    def parse_subpage(self, response):
        CODE_SELECTOR = ".//fieldset/table//*[@style='padding-left:40px;background:#cecece url(pliki/barcodeIcon.png) left no-repeat;background-size:40px;']/text()"
        PRICE_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-bottom:8px;background:#cecece url(pliki/cena.png) left no-repeat;background-size:contain;']/font/b/text()"
        FAV_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-top:8px;padding-bottom:9px;background:#cecece url(pliki/ulubione.png) left no-repeat;background-size:contain;']/font/b/text()"
        item = response.meta['item'] #Get the item we passed from scrape()

        item['kod'] = response.xpath(CODE_SELECTOR).extract()
        item['price'] = response.xpath(PRICE_SELECTOR).extract()
        item['fav'] = response.xpath(FAV_SELECTOR).extract()

        #item['price'] = response.xpath(PRICE_SELECTOR).extract()[1]
        #item['fav'] = response.xpath(PRICE_SELECTOR).extract()[0]
        yield item

    def url_join(self, url, response):
        joined_urls = []
        #for url in urls:
        joined_urls.append(response.urljoin(url))

        return joined_urls
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 21:51:23 2019

@author: Piotrek
"""

import scrapy
from piwko.items import PiwkoItem

def removeAccents(input_text):
    #http://gentle.pl/2017/07/19/usuwanie_polskich_znakow_python.html
    strange='ŮôῡΒძěἊἦëĐᾇόἶἧзвŅῑἼźἓŉἐÿἈΌἢὶЁϋυŕŽŎŃğûλВὦėἜŤŨîᾪĝžἙâᾣÚκὔჯᾏᾢĠфĞὝŲŊŁČῐЙῤŌὭŏყἀхῦЧĎὍОуνἱῺèᾒῘᾘὨШūლἚύсÁóĒἍŷöὄЗὤἥბĔõὅῥŋБщἝξĢюᾫაπჟῸდΓÕűřἅгἰშΨńģὌΥÒᾬÏἴქὀῖὣᾙῶŠὟὁἵÖἕΕῨčᾈķЭτἻůᾕἫжΩᾶŇᾁἣჩαἄἹΖеУŹἃἠᾞåᾄГΠКíōĪὮϊὂᾱიżŦИὙἮὖÛĮἳφᾖἋΎΰῩŚἷРῈĲἁéὃσňİΙῠΚĸὛΪᾝᾯψÄᾭêὠÀღЫĩĈμΆᾌἨÑἑïოĵÃŒŸζჭᾼőΣŻçųøΤΑËņĭῙŘАдὗპŰἤცᾓήἯΐÎეὊὼΘЖᾜὢĚἩħĂыῳὧďТΗἺĬὰὡὬὫÇЩᾧñῢĻᾅÆßшδòÂчῌᾃΉᾑΦÍīМƒÜἒĴἿťᾴĶÊΊȘῃΟúχΔὋŴćŔῴῆЦЮΝΛῪŢὯнῬũãáἽĕᾗნᾳἆᾥйᾡὒსᾎĆрĀüСὕÅýფᾺῲšŵкἎἇὑЛვёἂΏθĘэᾋΧĉᾐĤὐὴιăąäὺÈФĺῇἘſგŜæῼῄĊἏØÉПяწДĿᾮἭĜХῂᾦωთĦлðὩზკίᾂᾆἪпἸиᾠώᾀŪāоÙἉἾρаđἌΞļÔβĖÝᾔĨНŀęᾤÓцЕĽŞὈÞუтΈέıàᾍἛśìŶŬȚĳῧῊᾟάεŖᾨᾉςΡმᾊᾸįᾚὥηᾛġÐὓłγľмþᾹἲἔбċῗჰხοἬŗŐἡὲῷῚΫŭᾩὸùᾷĹēრЯĄὉὪῒᾲΜᾰÌœĥტ'
    ascii_replacements='UoyBdeAieDaoiiZVNiIzeneyAOiiEyyrZONgulVoeETUiOgzEaoUkyjAoGFGYUNLCiIrOOoqaKyCDOOUniOeiIIOSulEySAoEAyooZoibEoornBSEkGYOapzOdGOuraGisPngOYOOIikoioIoSYoiOeEYcAkEtIuiIZOaNaicaaIZEUZaiIaaGPKioIOioaizTIYIyUIifiAYyYSiREIaeosnIIyKkYIIOpAOeoAgYiCmAAINeiojAOYzcAoSZcuoTAEniIRADypUitiiIiIeOoTZIoEIhAYoodTIIIaoOOCSonyKaAsSdoACIaIiFIiMfUeJItaKEISiOuxDOWcRoiTYNLYTONRuaaIeinaaoIoysACRAuSyAypAoswKAayLvEaOtEEAXciHyiiaaayEFliEsgSaOiCAOEPYtDKOIGKiootHLdOzkiaaIPIIooaUaOUAIrAdAKlObEYiINleoOTEKSOTuTEeiaAEsiYUTiyIIaeROAsRmAAiIoiIgDylglMtAieBcihkoIrOieoIYuOouaKerYAOOiaMaIoht'
    translator=str.maketrans(strange,ascii_replacements)
    return input_text.translate(translator)

class PiwkoSpider(scrapy.Spider):
    name = 'piwko_spider'
    start_urls = ['https://ocen-piwo.pl/katalog-piw-14810']

    def parse(self, response):
        for item in self.scrape(response):
            yield item

    def scrape(self, response):
        SET_SELECTOR = './/fieldset'
        for brickset in response.xpath(SET_SELECTOR):

            item = PiwkoItem()
            NAME_SELECTOR = 'legend/a/text()'
            DETAILS_SELECTOR = 'legend/a/@href'
            TYPE_SELECTOR = 'table//div/a/@title'
            CNTRY_SELECTOR = 'table//div/a/text()'
            #ALKO_SELECTOR = "table//*[@class='tag']/text()"
            BLG_SELECTOR = "table//*[@class='tag']/text()"
            DATA_SELECTOR ="table//*[@class='news_add']/text()"
            #USER_SELECTOR = "table//*[@class='news_add']//a/text()"
            USER_SELECTOR = "table//*[@class='news_add']//text()"
            OPIS_SELECTOR = "table//*[@class='news_body']/div/text()"
            OCENA_SELECTOR = "table//*[@class='news_com']/font/text()"
            KOMENTARZE_SELECTOR = "table//*[@class='news_com']/b/text()"
            IBU_SELECTOR = "table//*[@style='padding-left:40px;background:#cecece url(pliki/ibuIcon.png) left no-repeat;background-size:contain;']/text()"
            IMG_SELECTOR = "table//img/@src"

            item['name']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(NAME_SELECTOR).extract_first().replace('\n', ' ')) ]),
            item['type']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(TYPE_SELECTOR).extract()[0].replace('dodaj do filtra::', '').replace('\n', ' ')) ]),
            item['kraj']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(CNTRY_SELECTOR).extract()[1]) ]).replace('\n', ' '),
            item['alko']=''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(BLG_SELECTOR).extract()[0].replace('\n', ' ')) ]),
            item['blg']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(BLG_SELECTOR).extract()[1].replace('\n', ' ')) ]),
            item['data_dod']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(DATA_SELECTOR).extract()[1].replace('\n', ' ')) ]),
            item['user']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(USER_SELECTOR).extract()[1].replace('\n', ' ')) ]),
            item['opis']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(OPIS_SELECTOR).extract()).replace('\n', ' ')) ]),
            item['ocena']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(OCENA_SELECTOR).extract()).replace('\n', ' ')) ]),
            item['ibu']=''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(IBU_SELECTOR).extract()).replace('\n', ' ')) ]),
            #relative_img_urls = response.xpath(IMG_SELECTOR).extract_first()
            item["file_urls"] = self.url_join(brickset.xpath(IMG_SELECTOR).extract_first(), response)

            #if(int(brickset.xpath(KOMENTARZE_SELECTOR).extract_first()) > 0):
            #request= scrapy.Request(response.urljoin(brickset.xpath(DETAILS_SELECTOR).extract_first()), callback=self.parse_subpage)
            request= scrapy.Request(response.urljoin(brickset.xpath(DETAILS_SELECTOR).extract_first()), callback=self.parse_subpage)
            request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            yield request
            
        NEXT_PAGE_SELECTOR = ".//*[@style='text-align:center;width:100%;']/a/@href"    
        next_page = response.xpath(NEXT_PAGE_SELECTOR)[-1].extract()
        if next_page:
            yield scrapy.Request(
                    response.urljoin(next_page),
                    callback=self.parse
                    )


    def parse_subpage(self, response):
        CODE_SELECTOR = ".//fieldset/table//*[@style='padding-left:40px;background:#cecece url(pliki/barcodeIcon.png) left no-repeat;background-size:40px;']/text()"
        PRICE_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-bottom:8px;background:#cecece url(pliki/cena.png) left no-repeat;background-size:contain;']/font/b/text()"
        FAV_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-top:8px;padding-bottom:9px;background:#cecece url(pliki/ulubione.png) left no-repeat;background-size:contain;']/font/b/text()"
        item = response.meta['item'] #Get the item we passed from scrape()

        item['kod'] = response.xpath(CODE_SELECTOR).extract()
        item['price'] = response.xpath(PRICE_SELECTOR).extract()
        item['fav'] = response.xpath(FAV_SELECTOR).extract()

        #item['price'] = response.xpath(PRICE_SELECTOR).extract()[1]
        #item['fav'] = response.xpath(PRICE_SELECTOR).extract()[0]
        yield item

    def url_join(self, url, response):
        joined_urls = []
        #for url in urls:
        joined_urls.append(response.urljoin(url))

        return joined_urls
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 21:51:23 2019

@author: Piotrek
"""

import scrapy
from piwko.items import PiwkoItem

def removeAccents(input_text):
    #http://gentle.pl/2017/07/19/usuwanie_polskich_znakow_python.html
    strange='ŮôῡΒძěἊἦëĐᾇόἶἧзвŅῑἼźἓŉἐÿἈΌἢὶЁϋυŕŽŎŃğûλВὦėἜŤŨîᾪĝžἙâᾣÚκὔჯᾏᾢĠфĞὝŲŊŁČῐЙῤŌὭŏყἀхῦЧĎὍОуνἱῺèᾒῘᾘὨШūლἚύсÁóĒἍŷöὄЗὤἥბĔõὅῥŋБщἝξĢюᾫაπჟῸდΓÕűřἅгἰშΨńģὌΥÒᾬÏἴქὀῖὣᾙῶŠὟὁἵÖἕΕῨčᾈķЭτἻůᾕἫжΩᾶŇᾁἣჩαἄἹΖеУŹἃἠᾞåᾄГΠКíōĪὮϊὂᾱიżŦИὙἮὖÛĮἳφᾖἋΎΰῩŚἷРῈĲἁéὃσňİΙῠΚĸὛΪᾝᾯψÄᾭêὠÀღЫĩĈμΆᾌἨÑἑïოĵÃŒŸζჭᾼőΣŻçųøΤΑËņĭῙŘАдὗპŰἤცᾓήἯΐÎეὊὼΘЖᾜὢĚἩħĂыῳὧďТΗἺĬὰὡὬὫÇЩᾧñῢĻᾅÆßшδòÂчῌᾃΉᾑΦÍīМƒÜἒĴἿťᾴĶÊΊȘῃΟúχΔὋŴćŔῴῆЦЮΝΛῪŢὯнῬũãáἽĕᾗნᾳἆᾥйᾡὒსᾎĆрĀüСὕÅýფᾺῲšŵкἎἇὑЛვёἂΏθĘэᾋΧĉᾐĤὐὴιăąäὺÈФĺῇἘſგŜæῼῄĊἏØÉПяწДĿᾮἭĜХῂᾦωთĦлðὩზკίᾂᾆἪпἸиᾠώᾀŪāоÙἉἾρаđἌΞļÔβĖÝᾔĨНŀęᾤÓцЕĽŞὈÞუтΈέıàᾍἛśìŶŬȚĳῧῊᾟάεŖᾨᾉςΡმᾊᾸįᾚὥηᾛġÐὓłγľмþᾹἲἔбċῗჰხοἬŗŐἡὲῷῚΫŭᾩὸùᾷĹēრЯĄὉὪῒᾲΜᾰÌœĥტ'
    ascii_replacements='UoyBdeAieDaoiiZVNiIzeneyAOiiEyyrZONgulVoeETUiOgzEaoUkyjAoGFGYUNLCiIrOOoqaKyCDOOUniOeiIIOSulEySAoEAyooZoibEoornBSEkGYOapzOdGOuraGisPngOYOOIikoioIoSYoiOeEYcAkEtIuiIZOaNaicaaIZEUZaiIaaGPKioIOioaizTIYIyUIifiAYyYSiREIaeosnIIyKkYIIOpAOeoAgYiCmAAINeiojAOYzcAoSZcuoTAEniIRADypUitiiIiIeOoTZIoEIhAYoodTIIIaoOOCSonyKaAsSdoACIaIiFIiMfUeJItaKEISiOuxDOWcRoiTYNLYTONRuaaIeinaaoIoysACRAuSyAypAoswKAayLvEaOtEEAXciHyiiaaayEFliEsgSaOiCAOEPYtDKOIGKiootHLdOzkiaaIPIIooaUaOUAIrAdAKlObEYiINleoOTEKSOTuTEeiaAEsiYUTiyIIaeROAsRmAAiIoiIgDylglMtAieBcihkoIrOieoIYuOouaKerYAOOiaMaIoht'
    translator=str.maketrans(strange,ascii_replacements)
    return input_text.translate(translator)

class PiwkoSpider(scrapy.Spider):
    name = 'piwko_spider'
    #start_urls = ['https://ocen-piwo.pl/katalog-piw-14810']
    start_urls = ['https://ocen-piwo.pl/fourpure-spice-route-s1-n10703']
    def parse(self, response):
        for item in self.scrape(response):
            yield item

    def scrape(self, response):
        SET_SELECTOR = './/fieldset'
        brickset = response.xpath(SET_SELECTOR)

        item = PiwkoItem()
        NAME_SELECTOR = 'legend/a/text()'
        FAV_SELECTOR = "table//*[@style='padding-left:40px;padding-top:8px;padding-bottom:9px;background:#cecece url(pliki/ulubione.png) left no-repeat;background-size:contain;']//b/text()"
        OCENA_SELECTOR = "table//*[@style='font-size:30px;']/text()"
        NOCENA_SELECTOR  = "table//*[@style='font-size:20px;']/text()"
        PRICE_SELECTOR = "table//*[@style='padding-left:40px;padding-bottom:8px;background:#cecece url(pliki/cena.png) left no-repeat;background-size:contain;']//b/text()"
            
            #KOMENTARZE_SELECTOR = "table//*[@class='news_com']/b/text()"

        item['name']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(brickset.xpath(NAME_SELECTOR).extract_first().replace('\n', ' ')) ]),
        item['ocena']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(OCENA_SELECTOR).extract()[-1]).replace('\n', ' ')) ]),
        item['fav']= ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(FAV_SELECTOR).extract()).replace('\n', ' ')) ]),
        item['nfav'] = ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(NOCENA_SELECTOR).extract()[-1]).replace('\n', ' ')) ]),
        item['price'] = ''.join([i if ord(i) < 128 else ' ' for i in removeAccents(u"".join(brickset.xpath(PRICE_SELECTOR).extract()).replace('\n', ' ')) ]),
             
        yield item
            #request= scrapy.Request(response.urljoin(brickset.xpath(DETAILS_SELECTOR).extract_first()), callback=self.parse_subpage)
            #request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            #yield request
            
        NEXT_PAGE_SELECTOR = ".//*[@style='text-align:right;width:680px;margin-bottom:10px;']/a/@href"    
        next_page = response.xpath(NEXT_PAGE_SELECTOR)[-1].extract()
        if next_page:
            yield scrapy.Request(
                    response.urljoin(next_page),
                    callback=self.parse
                    )


    def parse_subpage(self, response):
        CODE_SELECTOR = ".//fieldset/table//*[@style='padding-left:40px;background:#cecece url(pliki/barcodeIcon.png) left no-repeat;background-size:40px;']/text()"
        PRICE_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-bottom:8px;background:#cecece url(pliki/cena.png) left no-repeat;background-size:contain;']/font/b/text()"
        FAV_SELECTOR = ".//fieldset/table//*[@stlye='padding-left:40px;padding-top:8px;padding-bottom:9px;background:#cecece url(pliki/ulubione.png) left no-repeat;background-size:contain;']/font/b/text()"
        item = response.meta['item'] #Get the item we passed from scrape()

        item['kod'] = response.xpath(CODE_SELECTOR).extract()
        item['price'] = response.xpath(PRICE_SELECTOR).extract()
        item['fav'] = response.xpath(FAV_SELECTOR).extract()

        #item['price'] = response.xpath(PRICE_SELECTOR).extract()[1]
        #item['fav'] = response.xpath(PRICE_SELECTOR).extract()[0]
        yield item

    def url_join(self, url, response):
        joined_urls = []
        #for url in urls:
        joined_urls.append(response.urljoin(url))

        return joined_urls